// JavaScript Section
// Game configuration
const config = {
  emojiPairs: ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', 
               '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🐔',
               '🦄', '🐝', '🦋', '🐢', '🐍', '🦖', '🦕', '🐙'],
  modes: {
    easy: { pairs: 8, preview: 3000, timeLimit: 0, grid: 4 },
    medium: { pairs: 8, preview: 0, timeLimit: 0, grid: 4 },
    hard: { pairs: 8, preview: 0, timeLimit: 60, grid: 4 },
    memory: { pairs: 18, preview: 5000, timeLimit: 0, grid: 6 },
    speedrun: { pairs: 8, preview: 0, timeLimit: 0, grid: 4, noDelay: true }
  },
  descriptions: {
    easy: "🟢 Easy: Cards preview for 3 seconds before starting",
    medium: "🟡 Medium: No preview - standard memory challenge",
    hard: "🔴 Hard: Timed challenge - complete before time runs out!",
    memory: "🔥 Memory Mode: Larger 6×6 grid with 18 pairs to match",
    speedrun: "⚡ Speedrun Mode: No delays between flips! Great for setting record times!"
  }
};

// Game state
const state = {
  cards: [],
  flippedCards: [],
  matchedPairs: 0,
  moves: 0,
  seconds: 0,
  timer: null,
  currentMode: 'medium',
  isPreviewShown: false,
  isGameStarted: false
};

// DOM elements
const elements = {
  gameBoard: document.getElementById('game-board'),
  timeDisplay: document.getElementById('time'),
  movesDisplay: document.getElementById('moves'),
  matchesDisplay: document.getElementById('matches'),
  totalPairsDisplay: document.getElementById('total-pairs'),
  modeDescription: document.getElementById('mode-description'),
  restartBtn: document.getElementById('restart'),
  modeBtns: document.querySelectorAll('.mode-btn'),
  winMessage: document.getElementById('win-message')
};

// Initialize the game
function initGame() {
  setupEventListeners();
  setGameMode('medium');
  createBoard();
}

// Set up event listeners
function setupEventListeners() {
  elements.restartBtn.addEventListener('click', resetGame);
  
  elements.modeBtns.forEach(btn => {
    if (btn.id !== 'restart') {
      btn.addEventListener('click', () => setGameMode(btn.dataset.mode));
    }
  });
}

// Set the game mode
function setGameMode(mode) {
  state.currentMode = mode;
  const modeConfig = config.modes[mode];
  
  // Update UI
  elements.modeBtns.forEach(btn => {
    btn.classList.remove('active');
    if (btn.dataset.mode === mode) {
      btn.classList.add('active');
    }
  });
  
  elements.modeDescription.textContent = config.descriptions[mode];
  elements.totalPairsDisplay.textContent = modeConfig.pairs;
  
  resetGame();
}

// Create the game board
function createBoard() {
  elements.gameBoard.innerHTML = '';
  const modeConfig = config.modes[state.currentMode];
  
  // Select emojis and shuffle
  const selectedEmojis = config.emojiPairs.slice(0, modeConfig.pairs);
  state.cards = [...selectedEmojis, ...selectedEmojis];
  state.cards = shuffleArray(state.cards);
  
  // Set up grid
  elements.gameBoard.style.gridTemplateColumns = `repeat(${modeConfig.grid}, 1fr)`;
  
  // Create cards
  state.cards.forEach((emoji, index) => {
    const card = document.createElement('div');
    card.className = 'card';
    card.dataset.index = index;
    card.dataset.value = emoji;
    
    const cardFront = document.createElement('div');
    cardFront.className = 'card-face card-front';
    cardFront.textContent = '?';
    
    const cardBack = document.createElement('div');
    cardBack.className = 'card-face card-back';
    cardBack.textContent = emoji;
    
    card.appendChild(cardFront);
    card.appendChild(cardBack);
    card.addEventListener('click', () => flipCard(card));
    
    elements.gameBoard.appendChild(card);
  });
  
  // Show preview if applicable
  if (modeConfig.preview > 0) {
    showPreview(modeConfig.preview);
  }
}

// Show card preview
function showPreview(duration) {
  state.isPreviewShown = true;
  const cards = document.querySelectorAll('.card');
  
  cards.forEach(card => card.classList.add('flipped'));
  
  setTimeout(() => {
    cards.forEach(card => card.classList.remove('flipped'));
    state.isPreviewShown = false;
    startGame();
  }, duration);
}

// Start the game
function startGame() {
  if (!state.isGameStarted) {
    state.isGameStarted = true;
    resetTimer();
    startTimer();
  }
}

// Flip a card
function flipCard(card) {
  const modeConfig = config.modes[state.currentMode];
  
  // Prevent invalid moves
  if (state.isPreviewShown || 
      (state.currentMode === 'medium' && !state.isGameStarted) ||
      card.classList.contains('matched') || 
      card.classList.contains('flipped') || 
      state.flippedCards.length >= 2) {
    return;
  }
  
  // Start game on first move (for modes without preview)
  if (!state.isGameStarted) startGame();
  
  card.classList.add('flipped');
  state.flippedCards.push(card);
  
  // Check for match when two cards are flipped
  if (state.flippedCards.length === 2) {
    state.moves++;
    elements.movesDisplay.textContent = state.moves;
    
    const [card1, card2] = state.flippedCards;
    
    if (card1.dataset.value === card2.dataset.value) {
      // Match found
      card1.classList.add('matched');
      card2.classList.add('matched');
      state.flippedCards = [];
      state.matchedPairs++;
      elements.matchesDisplay.textContent = state.matchedPairs;
      
      // Check for win
      if (state.matchedPairs === modeConfig.pairs) {
        endGame(true);
      }
    } else {
      // No match
      if (!modeConfig.noDelay) {
        setTimeout(() => {
          card1.classList.remove('flipped');
          card2.classList.remove('flipped');
          state.flippedCards = [];
        }, 1000);
      } else {
        state.flippedCards = [];
      }
    }
  }
}

// Timer functions
function startTimer() {
  state.timer = setInterval(() => {
    state.seconds++;
    elements.timeDisplay.textContent = state.seconds;
    
    // Hard mode time limit check
    const modeConfig = config.modes[state.currentMode];
    if (modeConfig.timeLimit > 0 && state.seconds >= modeConfig.timeLimit) {
      endGame(false);
    }
  }, 1000);
}

function resetTimer() {
  clearInterval(state.timer);
  state.seconds = 0;
  elements.timeDisplay.textContent = '0';
}

function stopTimer() {
  clearInterval(state.timer);
}

// End the game
function endGame(isWin) {
  stopTimer();
  state.isGameStarted = false;
  
  elements.winMessage.style.display = 'block';
  
  if (isWin) {
    const emoji = state.currentMode === 'hard' ? '🏆' : '🎉';
    elements.winMessage.textContent = `${emoji} You won in ${state.seconds}s with ${state.moves} moves! ${emoji}`;
    elements.winMessage.style.background = '#2ecc71';
  } else {
    elements.winMessage.textContent = `⏰ Time's up! You matched ${state.matchedPairs} pairs. Try again!`;
    elements.winMessage.style.background = '#e74c3c';
  }
  
  setTimeout(() => {
    elements.winMessage.style.display = 'none';
  }, 5000);
}

// Reset the game
function resetGame() {
  stopTimer();
  state.flippedCards = [];
  state.matchedPairs = 0;
  state.moves = 0;
  state.seconds = 0;
  state.isGameStarted = false;
  state.isPreviewShown = false;
  
  elements.movesDisplay.textContent = '0';
  elements.matchesDisplay.textContent = '0';
  elements.timeDisplay.textContent = '0';
  elements.winMessage.style.display = 'none';
  
  createBoard();
}

// Helper function to shuffle array
function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// Initialize the game when page loads
window.addEventListener('DOMContentLoaded', initGame);